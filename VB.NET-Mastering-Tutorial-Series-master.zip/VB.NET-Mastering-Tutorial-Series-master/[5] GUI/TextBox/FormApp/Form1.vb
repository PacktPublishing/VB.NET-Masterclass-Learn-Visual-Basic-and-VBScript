﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtAwesome.Text = "Hello World"
    End Sub
End Class
