﻿Module Module1

    Sub Main()
        Dim Name As Integer
        Name = 4

        Dim Var2 As Integer
        Var2 = 8

        Console.WriteLine(Name)
        Console.WriteLine(Var2)
        Console.WriteLine(Name * Var2)

        Console.WriteLine("Input a number")

        Var2 = Console.ReadLine()
        Console.WriteLine(Name)
        Console.WriteLine(Var2)
        Console.WriteLine(Name * Var2)
    End Sub

End Module
