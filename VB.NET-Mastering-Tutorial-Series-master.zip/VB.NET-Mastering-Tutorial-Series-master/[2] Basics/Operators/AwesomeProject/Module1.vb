﻿Module Module1

    Sub Main()
        ' Arithmetic Operators
        Console.WriteLine(5 + 9)

        ' Comparison Operators
        Console.WriteLine(5 = 9)
        Console.WriteLine(5 = 5)
        Console.WriteLine(5 < 9)

        ' Logical/Bitwise Operators
        Console.WriteLine(5 And 9)

        ' Assignment Operators
        Dim Var As Integer
        Var = 9
        Console.WriteLine(Var)
        Var += 10 ' Var = Var + 10
        Console.WriteLine(Var)
    End Sub

End Module
