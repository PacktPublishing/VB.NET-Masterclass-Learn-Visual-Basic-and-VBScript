﻿Module Module1

    Sub Main()
        ' Hello this is awesome
        'Console.WriteLine("Hello")
        Console.WriteLine("World")
        Console.WriteLine("I")
        Console.WriteLine("Am")
        Console.WriteLine("Frahaan")
    End Sub

End Module
