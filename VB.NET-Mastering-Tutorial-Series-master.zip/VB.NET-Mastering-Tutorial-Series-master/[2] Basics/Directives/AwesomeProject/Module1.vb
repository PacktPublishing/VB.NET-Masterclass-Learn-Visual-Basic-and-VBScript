﻿Module Module1
#Const name = "8"
    Sub Main()
#If name = "Frahaan" Then
        Console.WriteLine("Enter")
#ElseIf name = "Batman" Then
        Console.WriteLine("OOOOO")
#Else
        Console.WriteLine("Default")
#End If
    End Sub

End Module
