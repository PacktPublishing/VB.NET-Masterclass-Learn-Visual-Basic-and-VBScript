﻿Module Module1

    Sub Main()
        Const VarAwesome As Integer = 4

        Dim Var2 As Integer
        Var2 = 5

        Console.WriteLine(VarAwesome)
        Console.WriteLine(Var2)
        Console.WriteLine(Var2 * VarAwesome)

        VarAwesome = Var2
    End Sub

End Module
