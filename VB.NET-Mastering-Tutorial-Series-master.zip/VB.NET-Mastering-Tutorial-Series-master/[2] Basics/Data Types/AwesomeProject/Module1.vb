﻿Module Module1

    Sub Main()
        Dim IntVar As Integer
        IntVar = 2147483647

        Dim LongVar As Long
        LongVar = 2147483648

        Dim DoubleVar As Double
        DoubleVar = 4.5

        Dim CharVar As Char
        CharVar = "3"

        Dim StringVar As String
        StringVar = "Hello World"

        Dim BooleanVar As Boolean
        BooleanVar = False

        Console.WriteLine(IntVar)
        Console.WriteLine(LongVar)
        Console.WriteLine(DoubleVar)
        Console.WriteLine(CharVar)
        Console.WriteLine(StringVar)
        Console.WriteLine(BooleanVar)

    End Sub

End Module
