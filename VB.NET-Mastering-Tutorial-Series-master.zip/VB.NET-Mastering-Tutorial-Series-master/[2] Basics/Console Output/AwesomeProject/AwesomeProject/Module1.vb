﻿Module Module1

    Sub Main()
        Console.Write("Awesome" & " you are amazing ")
        Console.WriteLine("Hello World")
        Console.Write("Project")
    End Sub

End Module
