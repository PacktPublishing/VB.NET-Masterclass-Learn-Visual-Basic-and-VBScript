﻿Module Module1
    Enum Cars
        BMW = 6
        MERCEDEZ
        HONDA = 90
        FARADAYFUTURE
    End Enum


    Sub Main()
        Console.WriteLine(Cars.BMW)
        Console.WriteLine(Cars.MERCEDEZ)
        Console.WriteLine(Cars.HONDA)
        Console.WriteLine(Cars.FARADAYFUTURE)
    End Sub

End Module
