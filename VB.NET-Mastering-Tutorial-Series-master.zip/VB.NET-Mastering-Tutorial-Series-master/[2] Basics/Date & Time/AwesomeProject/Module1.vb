﻿Module Module1

    Sub Main()
        Console.WriteLine(Now.ToLongTimeString)
        Console.WriteLine(Now.ToShortTimeString)

        Dim d As Date = Today

        Console.WriteLine("{0}", d)
    End Sub

End Module
